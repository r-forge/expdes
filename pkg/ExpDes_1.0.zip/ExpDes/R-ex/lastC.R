### Name: lastC
### Title: lastC
### Aliases: lastC
### Keywords: ~kwd1 ~kwd2

### ** Examples

library(agricolae)
x<-c("a","ab","b","c","cd")
lastC(x)
# "a" "b" "b" "c" "d"




