### Name: order.stat.SNK
### Title: order.stat.SNK
### Aliases: order.stat.SNK
### Keywords: ~kwd1 ~kwd2

### ** Examples

library(agricolae)
treatments <- c("A","B","C","D","E","F")
means<-c(2,5,3,7,9,5)
minimum.diff <- 2
groups<-order.stat(treatments,means,minimum.diff)



